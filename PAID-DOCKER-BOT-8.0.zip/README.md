# PAID-DOCKER-BOT-8.0

Docker backend conversion of the uploaded PAID-LXC-BOT-7.0.

## Install

```bash
sudo apt update
sudo apt install -y docker.io socat python3 python3-pip
sudo systemctl enable --now docker
python3 -m pip install -r requirements.txt
```

Set the bot token before starting:

```bash
export DISCORD_TOKEN='YOUR_NEW_DISCORD_BOT_TOKEN'
export YOUR_SERVER_IP='YOUR_VPS_IP'
python3 PAID-DOCKER-BOT-8.0.py
```

Do not put a real Discord token into GitHub.

## Important differences

- Containers are Docker containers, not LXC containers or KVM VMs.
- RAM and CPU limits are enforced with Docker.
- Docker does not provide a portable per-container disk quota through `docker update`; the existing disk value is therefore not a universal hard storage quota.
- Dynamic port forwarding uses `socat`; the bot expects `socat` to be installed.
- Some LXC-only security/kernel settings are ignored because Docker has different primitives.
- Existing Discord command names/UI are retained where practical, including the legacy `lxc-list` command name for compatibility.
- Snapshot/restore is implemented using Docker image commits and is not byte-for-byte equivalent to LXC snapshots.

The uploaded original bot contained a Discord token fallback. This conversion removes that fallback and requires `DISCORD_TOKEN` from the environment.
